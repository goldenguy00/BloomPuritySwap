## 1.0.3

- LookingGlass support

## 1.0.0

- Initial release