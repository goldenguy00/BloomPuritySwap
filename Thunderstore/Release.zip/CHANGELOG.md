## 1.0.2

- LookingGlass support

## 1.0.0

- Initial release